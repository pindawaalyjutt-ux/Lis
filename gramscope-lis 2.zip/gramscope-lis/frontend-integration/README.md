# Connecting the GramScope frontend to the real backend

The single-file artifact (`GramStainAI.jsx`) currently persists data with a local
`store` helper (`window.storage`). To make it **multi-user and permanent**, swap that
data layer for the REST API in `api.js`. Two clean options:

## Option A — Move into a Vite React project (recommended for production)
1. `npm create vite@latest gramscope-frontend -- --template react`
2. `cd gramscope-frontend && npm i recharts lucide-react xlsx`
3. Drop the artifact's components into `src/` (split into files as you prefer).
4. Copy `api.js` into `src/lib/api.js`.
5. Replace the `App` component's state-loading and CRUD actions so they call the API
   instead of `store`. Mapping:

| App action            | API call                          |
|-----------------------|-----------------------------------|
| `onLogin`             | `api.login(username, password)` → `setToken(res.access_token)` |
| load patients         | `api.listPatients()`              |
| `addPatient`          | `api.addPatient(f)`               |
| `updatePatient`       | `api.updatePatient(id, patch)`    |
| `deletePatient`       | `api.deletePatient(id)`           |
| load/CRUD reports     | `api.listReports()` / `createReport` / `updateReport` / `reopenReport` |
| catalog               | `api.catalog()` / `addCategory` / `addTemplate` … |
| users (admin)         | `api.listUsers()` / `addUser` …   |
| dashboard KPIs        | `api.dashboard()`                 |

6. `npm run build` → copy `dist/` into `desktop/renderer/` for the Electron build.

## Option B — Keep the file, replace only the `store` helper
Replace the `store` object with a thin wrapper that calls the API per `gs:` key
(e.g. `gs:patients` → `api.listPatients()`), and replace `onLogin` to call `api.login`.
This is faster but Option A gives cleaner separation.

> The **PDF/Excel report generators are 100% client-side** and need no changes — they
> already read the report object you pass them, whether it comes from local storage or the API.
