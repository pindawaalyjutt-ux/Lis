// GramScope LIS — API client for the FastAPI backend.
// Works in the browser and inside Electron (window.gramscope.apiBase).

const BASE =
  (typeof window !== "undefined" && window.gramscope && window.gramscope.apiBase) ||
  import.meta?.env?.VITE_API_BASE ||
  "http://localhost:8000";

const TOKEN_KEY = "gs:token";

export function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}
export function setToken(t) {
  if (t) localStorage.setItem(TOKEN_KEY, t);
  else localStorage.removeItem(TOKEN_KEY);
}

async function req(method, path, body) {
  const headers = { "Content-Type": "application/json" };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  if (res.status === 204) return null;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg = data?.detail || `Request failed (${res.status})`;
    throw new Error(Array.isArray(msg) ? msg.map((m) => m.msg).join(", ") : msg);
  }
  return data;
}

export const api = {
  // auth
  login: (username, password, otp) => req("POST", "/auth/login", { username, password, otp }),
  register: (payload) => req("POST", "/auth/register", payload),

  // dashboard
  dashboard: () => req("GET", "/dashboard"),

  // patients
  listPatients: (q) => req("GET", `/patients${q ? `?q=${encodeURIComponent(q)}` : ""}`),
  getPatient: (id) => req("GET", `/patients/${id}`),
  addPatient: (p) => req("POST", "/patients", p),
  updatePatient: (id, patch) => req("PATCH", `/patients/${id}`, patch),
  deletePatient: (id) => req("DELETE", `/patients/${id}`),

  // catalog
  catalog: () => req("GET", "/catalog"),
  addCategory: (name) => req("POST", "/catalog/categories", { name }),
  deleteCategory: (id) => req("DELETE", `/catalog/categories/${id}`),
  addTemplate: (cid, t) => req("POST", `/catalog/categories/${cid}/tests`, t),
  deleteTemplate: (tid) => req("DELETE", `/catalog/tests/${tid}`),

  // reports
  listReports: (patientId) =>
    req("GET", `/reports${patientId ? `?patient_id=${patientId}` : ""}`),
  getReport: (id) => req("GET", `/reports/${id}`),
  createReport: (r) => req("POST", "/reports", r),
  updateReport: (id, patch) => req("PATCH", `/reports/${id}`, patch),
  reopenReport: (id) => req("POST", `/reports/${id}/reopen`),
  addReportNote: (id, text) => req("POST", `/reports/${id}/notes`, { text }),
  deleteReport: (id) => req("DELETE", `/reports/${id}`),

  // users (admin)
  listUsers: () => req("GET", "/users"),
  addUser: (u) => req("POST", "/users", u),
  updateUser: (id, patch) => req("PATCH", `/users/${id}`, patch),
  deleteUser: (id) => req("DELETE", `/users/${id}`),

  // appointments / qc / audit
  listAppointments: () => req("GET", "/appointments"),
  addAppointment: (a) => req("POST", "/appointments", a),
  updateAppointment: (id, patch) => req("PATCH", `/appointments/${id}`, patch),
  listQC: () => req("GET", "/qc"),
  addQC: (q) => req("POST", "/qc", q),
  listAudit: () => req("GET", "/audit"),
};
