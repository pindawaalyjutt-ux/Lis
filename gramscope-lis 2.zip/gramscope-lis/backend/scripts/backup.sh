#!/usr/bin/env bash
# Daily database backup. Render cron filesystem is ephemeral, so we ship the
# dump offsite to S3 (or any S3-compatible store like Backblaze B2 / Wasabi).
set -euo pipefail
STAMP=$(date +%Y%m%d-%H%M%S)
FILE="/tmp/gramscope-${STAMP}.sql.gz"

echo "[backup] dumping database…"
pg_dump "${DATABASE_URL}" | gzip > "${FILE}"
echo "[backup] dump size: $(du -h "${FILE}" | cut -f1)"

if [[ -n "${BACKUP_S3_BUCKET:-}" ]]; then
  echo "[backup] uploading to s3://${BACKUP_S3_BUCKET}/"
  aws s3 cp "${FILE}" "s3://${BACKUP_S3_BUCKET}/gramscope-${STAMP}.sql.gz"
  echo "[backup] done."
else
  echo "[backup] BACKUP_S3_BUCKET not set — dump created locally only (will be lost on Render cron)."
  echo "[backup] Set BACKUP_S3_BUCKET + AWS creds to enable offsite storage."
fi
