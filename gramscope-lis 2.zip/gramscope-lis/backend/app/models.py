import uuid
from datetime import datetime, timezone
from sqlalchemy import (Column, String, Integer, Boolean, DateTime, ForeignKey,
                        Text, JSON)
from sqlalchemy.orm import relationship
from .database import Base


def uid() -> str:
    return uuid.uuid4().hex[:12]


def now() -> datetime:
    return datetime.now(timezone.utc)


class User(Base):
    __tablename__ = "users"
    id = Column(String, primary_key=True, default=uid)
    username = Column(String, unique=True, index=True, nullable=False)
    name = Column(String, nullable=False)
    email = Column(String, default="")
    password_hash = Column(String, nullable=False)
    role = Column(String, default="Technician")           # Admin / Pathologist / Microbiologist / Technician
    permissions = Column(JSON, default=list)
    active = Column(Boolean, default=True)
    two_fa = Column(Boolean, default=False)
    failed_attempts = Column(Integer, default=0)
    locked_until = Column(DateTime(timezone=True), nullable=True)
    password_set_at = Column(DateTime(timezone=True), default=now)
    last_login = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=now)


class Patient(Base):
    __tablename__ = "patients"
    id = Column(String, primary_key=True, default=uid)
    mr_no = Column(String, unique=True, index=True)
    lab_no = Column(String, index=True)
    name = Column(String, nullable=False, index=True)
    age = Column(Integer, default=0)
    sex = Column(String, default="")
    contact = Column(String, default="")
    address = Column(String, default="")
    ward = Column(String, default="")
    specimen = Column(String, default="")
    physician = Column(String, default="")
    extra = Column(JSON, default=dict)   # visits / treatment / prescriptions / followups / documents
    created_at = Column(DateTime(timezone=True), default=now)

    reports = relationship("Report", back_populates="patient", cascade="all, delete-orphan")


class TestCategory(Base):
    __tablename__ = "test_categories"
    id = Column(String, primary_key=True, default=uid)
    name = Column(String, nullable=False)
    tests = relationship("TestTemplate", back_populates="category", cascade="all, delete-orphan")


class TestTemplate(Base):
    __tablename__ = "test_templates"
    id = Column(String, primary_key=True, default=uid)
    category_id = Column(String, ForeignKey("test_categories.id", ondelete="CASCADE"))
    name = Column(String, nullable=False)
    unit = Column(String, default="")
    ref_range = Column(String, default="")
    category = relationship("TestCategory", back_populates="tests")


class Report(Base):
    __tablename__ = "reports"
    id = Column(String, primary_key=True, default=uid)
    patient_id = Column(String, ForeignKey("patients.id", ondelete="CASCADE"), index=True)
    lab_no = Column(String, index=True)
    type = Column(String, default="gram")          # gram | panel
    category = Column(String, default="")
    status = Column(String, default="Draft")       # Draft | Reviewed | Released
    impression = Column(Text, default="")
    explanation = Column(Text, default="")
    image = Column(Text, default="")               # data-url (optional)
    result = Column(JSON, default=dict)            # gram findings
    confidence = Column(JSON, default=dict)
    metrics = Column(JSON, default=dict)
    annotations = Column(JSON, default=list)
    tests = Column(JSON, default=list)             # panel tests [{name,result,unit,range,remarks}]
    notes = Column(JSON, default=list)
    versions = Column(JSON, default=list)
    sign = Column(JSON, nullable=True)
    created_at = Column(DateTime(timezone=True), default=now)
    updated_at = Column(DateTime(timezone=True), default=now, onupdate=now)

    patient = relationship("Patient", back_populates="reports")


class Appointment(Base):
    __tablename__ = "appointments"
    id = Column(String, primary_key=True, default=uid)
    patient_name = Column(String, default="")
    doctor = Column(String, default="")
    date = Column(String, default="")
    time = Column(String, default="")
    reason = Column(String, default="")
    status = Column(String, default="Booked")
    created_at = Column(DateTime(timezone=True), default=now)


class QCRecord(Base):
    __tablename__ = "qc_records"
    id = Column(String, primary_key=True, default=uid)
    control = Column(String, default="")
    expected = Column(String, default="")
    observed = Column(String, default="")
    reagent_lot = Column(String, default="")
    result = Column(String, default="")
    by = Column(String, default="")
    created_at = Column(DateTime(timezone=True), default=now)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(String, primary_key=True, default=uid)
    user = Column(String, default="")
    role = Column(String, default="")
    action = Column(String, default="")
    target = Column(String, default="")
    at = Column(DateTime(timezone=True), default=now)
