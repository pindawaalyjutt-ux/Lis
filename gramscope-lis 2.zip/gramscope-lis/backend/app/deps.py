from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from .database import get_db
from .security import decode_token
from . import models

oauth2 = OAuth2PasswordBearer(tokenUrl="auth/login-form", auto_error=False)


def get_current_user(token: str = Depends(oauth2), db: Session = Depends(get_db)) -> models.User:
    if not token:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Not authenticated")
    payload = decode_token(token)
    if not payload:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or expired token")
    user = db.query(models.User).filter(models.User.username == payload.get("sub")).first()
    if not user or not user.active:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "User not found or inactive")
    return user


def has_perm(user: models.User, perm: str) -> bool:
    perms = user.permissions or []
    return "all" in perms or perm in perms or user.role == "Admin"


def require_perm(perm: str):
    def _dep(user: models.User = Depends(get_current_user)) -> models.User:
        if not has_perm(user, perm):
            raise HTTPException(status.HTTP_403_FORBIDDEN, f"Missing permission: {perm}")
        return user
    return _dep


def require_admin(user: models.User = Depends(get_current_user)) -> models.User:
    if user.role != "Admin":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Admin only")
    return user


def write_log(db: Session, user: models.User, action: str, target: str = ""):
    db.add(models.AuditLog(user=user.name, role=user.role, action=action, target=target))
    db.commit()
