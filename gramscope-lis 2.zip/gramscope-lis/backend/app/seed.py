"""Idempotent seeding: default admin + staff users and the test catalog."""
from .database import SessionLocal, Base, engine
from . import models
from .security import hash_password

ROLE_DEFAULTS = {
    "Admin": ["all"],
    "Pathologist": ["register", "analyze", "edit", "review", "finalize", "qc", "audit", "appointments", "deletePatient"],
    "Microbiologist": ["register", "analyze", "edit", "review", "qc", "appointments"],
    "Technician": ["register", "analyze", "appointments"],
}
SEED_USERS = [
    ("admin", "admin123", "Dr. A. Rauf", "admin@lab.pk", "Admin"),
    ("patho", "patho123", "Dr. S. Iqbal", "patho@lab.pk", "Pathologist"),
    ("micro", "micro123", "H. Nadeem", "micro@lab.pk", "Microbiologist"),
    ("tech", "tech123", "F. Bashir", "tech@lab.pk", "Technician"),
]
SEED_CATALOG = {
    "Hematology": [("Hemoglobin (Hb)", "g/dL", "13.0 - 17.0"), ("Total WBC Count", "x10^3/uL", "4.0 - 11.0"),
                   ("Platelet Count", "x10^3/uL", "150 - 410"), ("Hematocrit (HCT)", "%", "40 - 50"),
                   ("ESR", "mm/hr", "0 - 15")],
    "Biochemistry": [("Fasting Blood Glucose", "mg/dL", "70 - 100"), ("Blood Urea", "mg/dL", "15 - 40"),
                     ("Serum Creatinine", "mg/dL", "0.6 - 1.3"), ("ALT (SGPT)", "U/L", "0 - 40"),
                     ("Total Cholesterol", "mg/dL", "< 200")],
    "Serology": [("C-Reactive Protein (CRP)", "mg/L", "< 6"), ("RA Factor", "IU/mL", "< 14"),
                 ("HBsAg", "-", "Non-reactive"), ("Anti-HCV", "-", "Non-reactive")],
    "Microbiology": [("Gram Stain", "-", "No organisms seen"), ("Culture & Sensitivity", "-", "No growth"),
                     ("AFB Smear", "-", "Negative")],
    "Urinalysis": [("Colour", "-", "Pale yellow"), ("pH", "-", "4.6 - 8.0"), ("Protein", "-", "Nil"),
                   ("Pus Cells", "/HPF", "0 - 5"), ("RBC", "/HPF", "0 - 2")],
}


def run():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        if db.query(models.User).count() == 0:
            for username, pw, name, email, role in SEED_USERS:
                db.add(models.User(username=username, name=name, email=email, role=role,
                                   permissions=list(ROLE_DEFAULTS[role]),
                                   password_hash=hash_password(pw)))
            db.commit()
        if db.query(models.TestCategory).count() == 0:
            for cat, tests in SEED_CATALOG.items():
                c = models.TestCategory(name=cat)
                db.add(c); db.flush()
                for tname, unit, rng in tests:
                    db.add(models.TestTemplate(category_id=c.id, name=tname, unit=unit, ref_range=rng))
            db.commit()
    finally:
        db.close()


if __name__ == "__main__":
    run()
    print("Seed complete.")
