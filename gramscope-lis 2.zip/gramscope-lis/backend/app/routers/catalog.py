from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from .. import models, schemas
from ..database import get_db
from ..deps import get_current_user, require_perm, write_log

router = APIRouter(prefix="/catalog", tags=["catalog"])


@router.get("", response_model=list[schemas.CategoryOut])
def list_catalog(db: Session = Depends(get_db), _: models.User = Depends(get_current_user)):
    return db.query(models.TestCategory).order_by(models.TestCategory.name).all()


@router.post("/categories", response_model=schemas.CategoryOut, status_code=201)
def add_category(body: schemas.CategoryIn, db: Session = Depends(get_db),
                 user: models.User = Depends(require_perm("analyze"))):
    c = models.TestCategory(name=body.name)
    db.add(c); db.commit(); db.refresh(c)
    write_log(db, user, "Added test category", body.name)
    return c


@router.delete("/categories/{cid}", status_code=204)
def delete_category(cid: str, db: Session = Depends(get_db),
                    user: models.User = Depends(require_perm("analyze"))):
    c = db.get(models.TestCategory, cid)
    if not c:
        raise HTTPException(404, "Category not found")
    db.delete(c); db.commit()
    write_log(db, user, "Deleted test category", c.name)


@router.post("/categories/{cid}/tests", response_model=schemas.TemplateOut, status_code=201)
def add_template(cid: str, body: schemas.TemplateIn, db: Session = Depends(get_db),
                 user: models.User = Depends(require_perm("analyze"))):
    if not db.get(models.TestCategory, cid):
        raise HTTPException(404, "Category not found")
    t = models.TestTemplate(category_id=cid, name=body.name, unit=body.unit, ref_range=body.ref_range)
    db.add(t); db.commit(); db.refresh(t)
    write_log(db, user, "Added catalog test", body.name)
    return t


@router.delete("/tests/{tid}", status_code=204)
def delete_template(tid: str, db: Session = Depends(get_db),
                    user: models.User = Depends(require_perm("analyze"))):
    t = db.get(models.TestTemplate, tid)
    if not t:
        raise HTTPException(404, "Test not found")
    db.delete(t); db.commit()
    write_log(db, user, "Deleted catalog test", t.name)
