from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from .. import models, schemas
from ..database import get_db
from ..security import verify_password, hash_password, create_access_token
from ..config import settings

router = APIRouter(prefix="/auth", tags=["auth"])
ROLE_DEFAULTS = {
    "Admin": ["all"],
    "Pathologist": ["register", "analyze", "edit", "review", "finalize", "qc", "audit", "appointments", "deletePatient"],
    "Microbiologist": ["register", "analyze", "edit", "review", "qc", "appointments"],
    "Technician": ["register", "analyze", "appointments"],
}


def _authenticate(db: Session, username: str, password: str) -> models.User:
    user = db.query(models.User).filter(models.User.username == username.lower()).first()
    now = datetime.now(timezone.utc)
    if user and user.locked_until and user.locked_until > now:
        raise HTTPException(status.HTTP_423_LOCKED, "Account temporarily locked. Try again later.")
    if not user or not verify_password(password, user.password_hash):
        if user:
            user.failed_attempts = (user.failed_attempts or 0) + 1
            if user.failed_attempts >= 5:
                user.locked_until = now + timedelta(minutes=15)
            db.commit()
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid credentials")
    if not user.active:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Account deactivated")
    user.failed_attempts = 0
    user.locked_until = None
    user.last_login = now
    db.commit()
    return user


@router.post("/login", response_model=schemas.Token)
def login(body: schemas.LoginIn, db: Session = Depends(get_db)):
    user = _authenticate(db, body.username, body.password)
    db.add(models.AuditLog(user=user.name, role=user.role, action="Signed in"))
    db.commit()
    return schemas.Token(access_token=create_access_token(user.username, user.role),
                         user=schemas.UserOut.model_validate(user))


@router.post("/login-form", response_model=schemas.Token)
def login_form(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = _authenticate(db, form.username, form.password)
    return schemas.Token(access_token=create_access_token(user.username, user.role),
                         user=schemas.UserOut.model_validate(user))


@router.post("/register", response_model=schemas.UserOut, status_code=201)
def register(body: schemas.RegisterIn, db: Session = Depends(get_db)):
    if db.query(models.User).filter(models.User.username == body.username.lower()).first():
        raise HTTPException(409, "Username already taken")
    role = body.role if body.role in ROLE_DEFAULTS and body.role != "Admin" else "Technician"
    user = models.User(username=body.username.lower(), name=body.name, email=body.email,
                       password_hash=hash_password(body.password), role=role,
                       permissions=list(ROLE_DEFAULTS[role]))
    db.add(user)
    db.commit()
    db.refresh(user)
    return user
