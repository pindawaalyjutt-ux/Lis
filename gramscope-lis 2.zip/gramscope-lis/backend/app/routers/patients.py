from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import or_
from sqlalchemy.orm import Session
from .. import models, schemas
from ..database import get_db
from ..deps import get_current_user, require_perm, has_perm, write_log

router = APIRouter(prefix="/patients", tags=["patients"])


def _next_numbers(db: Session) -> tuple[str, str]:
    year = datetime.now().year
    ymd = datetime.now().strftime("%Y%m%d")
    count = db.query(models.Patient).count() + 1
    return f"MR-{year}-{count:05d}", f"GS-{ymd}-{count:03d}"


@router.get("", response_model=list[schemas.PatientOut])
def list_patients(q: str | None = Query(None), db: Session = Depends(get_db),
                  _: models.User = Depends(get_current_user)):
    query = db.query(models.Patient)
    if q:
        like = f"%{q}%"
        query = query.filter(or_(models.Patient.name.ilike(like),
                                 models.Patient.mr_no.ilike(like),
                                 models.Patient.lab_no.ilike(like),
                                 models.Patient.ward.ilike(like)))
    return query.order_by(models.Patient.created_at.desc()).all()


@router.get("/{pid}", response_model=schemas.PatientOut)
def get_patient(pid: str, db: Session = Depends(get_db), _: models.User = Depends(get_current_user)):
    p = db.get(models.Patient, pid)
    if not p:
        raise HTTPException(404, "Patient not found")
    return p


@router.post("", response_model=schemas.PatientOut, status_code=201)
def create_patient(body: schemas.PatientCreate, db: Session = Depends(get_db),
                   user: models.User = Depends(require_perm("register"))):
    mr, lab = _next_numbers(db)
    base = body.model_dump()
    base.setdefault("extra", {})
    for key in ("visits", "treatment", "prescriptions", "followups", "documents"):
        base["extra"].setdefault(key, [])
    p = models.Patient(mr_no=mr, lab_no=lab, **base)
    db.add(p); db.commit(); db.refresh(p)
    write_log(db, user, "Registered patient", p.mr_no)
    return p


@router.patch("/{pid}", response_model=schemas.PatientOut)
def update_patient(pid: str, body: schemas.PatientUpdate, db: Session = Depends(get_db),
                   user: models.User = Depends(require_perm("register"))):
    p = db.get(models.Patient, pid)
    if not p:
        raise HTTPException(404, "Patient not found")
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(p, k, v)
    db.commit(); db.refresh(p)
    write_log(db, user, "Updated patient", p.mr_no)
    return p


@router.delete("/{pid}", status_code=204)
def delete_patient(pid: str, db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    if not has_perm(user, "deletePatient"):
        raise HTTPException(403, "Missing permission: deletePatient")
    p = db.get(models.Patient, pid)
    if not p:
        raise HTTPException(404, "Patient not found")
    db.delete(p); db.commit()
    write_log(db, user, "Deleted patient", p.mr_no)
