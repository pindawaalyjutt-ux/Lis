from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from .. import models, schemas
from ..database import get_db
from ..deps import get_current_user, require_perm, write_log

router = APIRouter(tags=["misc"])


# ---------- Appointments ----------
@router.get("/appointments", response_model=list[schemas.AppointmentOut])
def list_appts(db: Session = Depends(get_db), _: models.User = Depends(get_current_user)):
    return db.query(models.Appointment).order_by(models.Appointment.date.desc()).all()


@router.post("/appointments", response_model=schemas.AppointmentOut, status_code=201)
def book_appt(body: schemas.AppointmentIn, db: Session = Depends(get_db),
              user: models.User = Depends(require_perm("appointments"))):
    a = models.Appointment(**body.model_dump())
    db.add(a); db.commit(); db.refresh(a)
    write_log(db, user, "Booked appointment", a.patient_name)
    return a


@router.patch("/appointments/{aid}", response_model=schemas.AppointmentOut)
def update_appt(aid: str, body: schemas.AppointmentIn, db: Session = Depends(get_db),
                user: models.User = Depends(require_perm("appointments"))):
    a = db.get(models.Appointment, aid)
    if not a:
        from fastapi import HTTPException
        raise HTTPException(404, "Appointment not found")
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(a, k, v)
    db.commit(); db.refresh(a)
    return a


# ---------- QC ----------
@router.get("/qc", response_model=list[schemas.QCOut])
def list_qc(db: Session = Depends(get_db), _: models.User = Depends(get_current_user)):
    return db.query(models.QCRecord).order_by(models.QCRecord.created_at.desc()).all()


@router.post("/qc", response_model=schemas.QCOut, status_code=201)
def add_qc(body: schemas.QCIn, db: Session = Depends(get_db),
           user: models.User = Depends(require_perm("qc"))):
    q = models.QCRecord(**body.model_dump(), by=user.name)
    db.add(q); db.commit(); db.refresh(q)
    write_log(db, user, "Logged QC", q.result)
    return q


# ---------- Audit ----------
@router.get("/audit", response_model=list[schemas.AuditOut])
def list_audit(limit: int = 500, db: Session = Depends(get_db),
               _: models.User = Depends(require_perm("audit"))):
    return db.query(models.AuditLog).order_by(models.AuditLog.at.desc()).limit(limit).all()


# ---------- Dashboard ----------
@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db), _: models.User = Depends(get_current_user)):
    total_reports = db.query(models.Report).count()
    released = db.query(models.Report).filter(models.Report.status == "Released").count()
    return {
        "patients": db.query(models.Patient).count(),
        "reports": total_reports,
        "pending": total_reports - released,
        "completed": released,
        "appointments": db.query(models.Appointment).filter(models.Appointment.status == "Booked").count(),
    }
