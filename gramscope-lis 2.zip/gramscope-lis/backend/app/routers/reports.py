from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from .. import models, schemas
from ..database import get_db
from ..deps import get_current_user, require_perm, has_perm, write_log

router = APIRouter(prefix="/reports", tags=["reports"])


def _snapshot(r: models.Report, action: str, by: str) -> dict:
    return {"at": datetime.now(timezone.utc).isoformat(), "by": by, "action": action,
            "status": r.status, "snapshot": {"gram": (r.result or {}).get("gram"),
                                             "category": r.category}}


@router.get("", response_model=list[schemas.ReportOut])
def list_reports(patient_id: str | None = None, db: Session = Depends(get_db),
                 _: models.User = Depends(get_current_user)):
    q = db.query(models.Report)
    if patient_id:
        q = q.filter(models.Report.patient_id == patient_id)
    return q.order_by(models.Report.updated_at.desc()).all()


@router.get("/{rid}", response_model=schemas.ReportOut)
def get_report(rid: str, db: Session = Depends(get_db), _: models.User = Depends(get_current_user)):
    r = db.get(models.Report, rid)
    if not r:
        raise HTTPException(404, "Report not found")
    return r


@router.post("", response_model=schemas.ReportOut, status_code=201)
def create_report(body: schemas.ReportCreate, db: Session = Depends(get_db),
                  user: models.User = Depends(require_perm("analyze"))):
    patient = db.get(models.Patient, body.patient_id)
    if not patient:
        raise HTTPException(404, "Patient not found")
    if body.status == "Released" and not has_perm(user, "finalize"):
        raise HTTPException(403, "Missing permission: finalize")
    sign = None
    if body.status == "Released":
        sign = {"by": user.name, "role": user.role,
                "initials": "".join(w[0] for w in user.name.split())[:3],
                "at": datetime.now(timezone.utc).isoformat()}
    r = models.Report(patient_id=patient.id, lab_no=patient.lab_no, type=body.type,
                      category=body.category, status=body.status, impression=body.impression,
                      explanation=body.explanation, image=body.image, result=body.result,
                      confidence=body.confidence, metrics=body.metrics, annotations=body.annotations,
                      tests=body.tests, notes=[], versions=[], sign=sign)
    db.add(r); db.commit(); db.refresh(r)
    write_log(db, user, "Created analysis", r.lab_no)
    return r


@router.patch("/{rid}", response_model=schemas.ReportOut)
def update_report(rid: str, body: schemas.ReportUpdate, db: Session = Depends(get_db),
                  user: models.User = Depends(get_current_user)):
    r = db.get(models.Report, rid)
    if not r:
        raise HTTPException(404, "Report not found")
    data = body.model_dump(exclude_unset=True)
    new_status = data.get("status")
    if new_status == "Reviewed" and not has_perm(user, "review"):
        raise HTTPException(403, "Missing permission: review")
    if new_status == "Released" and not has_perm(user, "finalize"):
        raise HTTPException(403, "Missing permission: finalize")
    if r.status == "Released" and new_status not in (None, "Released"):
        raise HTTPException(409, "Released report is locked. Reopen it first.")
    r.versions = (r.versions or []) + [_snapshot(r, f"Status -> {new_status}" if new_status else "Edited", user.name)]
    for k, v in data.items():
        setattr(r, k, v)
    if new_status == "Released" and not r.sign:
        r.sign = {"by": user.name, "role": user.role,
                  "initials": "".join(w[0] for w in user.name.split())[:3],
                  "at": datetime.now(timezone.utc).isoformat()}
    db.commit(); db.refresh(r)
    write_log(db, user, f"Report -> {new_status}" if new_status else "Edited report", r.lab_no)
    return r


@router.post("/{rid}/reopen", response_model=schemas.ReportOut)
def reopen_report(rid: str, db: Session = Depends(get_db),
                  user: models.User = Depends(require_perm("reopen"))):
    r = db.get(models.Report, rid)
    if not r:
        raise HTTPException(404, "Report not found")
    r.versions = (r.versions or []) + [_snapshot(r, "Reopened", user.name)]
    r.status = "Reviewed"
    db.commit(); db.refresh(r)
    write_log(db, user, "Reopened report", r.lab_no)
    return r


@router.post("/{rid}/notes", response_model=schemas.ReportOut)
def add_note(rid: str, body: schemas.NoteIn, db: Session = Depends(get_db),
             user: models.User = Depends(get_current_user)):
    r = db.get(models.Report, rid)
    if not r:
        raise HTTPException(404, "Report not found")
    r.notes = (r.notes or []) + [{"id": models.uid(), "text": body.text, "by": user.name,
                                  "at": datetime.now(timezone.utc).isoformat()}]
    db.commit(); db.refresh(r)
    return r


@router.delete("/{rid}", status_code=204)
def delete_report(rid: str, db: Session = Depends(get_db), user: models.User = Depends(require_perm("reopen"))):
    r = db.get(models.Report, rid)
    if not r:
        raise HTTPException(404, "Report not found")
    db.delete(r); db.commit()
    write_log(db, user, "Deleted report", r.lab_no)
