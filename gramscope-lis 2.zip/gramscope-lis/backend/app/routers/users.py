from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from .. import models, schemas
from ..database import get_db
from ..deps import require_admin, get_current_user, write_log
from ..security import hash_password
from .auth import ROLE_DEFAULTS

router = APIRouter(prefix="/users", tags=["users"])


@router.get("", response_model=list[schemas.UserOut])
def list_users(db: Session = Depends(get_db), _: models.User = Depends(require_admin)):
    return db.query(models.User).order_by(models.User.created_at).all()


@router.post("", response_model=schemas.UserOut, status_code=201)
def create_user(body: schemas.UserCreate, db: Session = Depends(get_db), admin: models.User = Depends(require_admin)):
    if db.query(models.User).filter(models.User.username == body.username.lower()).first():
        raise HTTPException(409, "Username already taken")
    perms = ["all"] if body.role == "Admin" else (body.permissions or list(ROLE_DEFAULTS.get(body.role, [])))
    user = models.User(username=body.username.lower(), name=body.name, email=body.email, role=body.role,
                       permissions=perms, active=body.active, two_fa=body.two_fa,
                       password_hash=hash_password(body.password))
    db.add(user); db.commit(); db.refresh(user)
    write_log(db, admin, "Created user", user.username)
    return user


@router.patch("/{uid}", response_model=schemas.UserOut)
def update_user(uid: str, body: schemas.UserUpdate, db: Session = Depends(get_db), admin: models.User = Depends(require_admin)):
    user = db.get(models.User, uid)
    if not user:
        raise HTTPException(404, "User not found")
    data = body.model_dump(exclude_unset=True)
    if "password" in data and data["password"]:
        user.password_hash = hash_password(data.pop("password"))
        from datetime import datetime, timezone
        user.password_set_at = datetime.now(timezone.utc)
    else:
        data.pop("password", None)
    for k, v in data.items():
        setattr(user, k, v)
    db.commit(); db.refresh(user)
    write_log(db, admin, "Updated user", user.username)
    return user


@router.delete("/{uid}", status_code=204)
def delete_user(uid: str, db: Session = Depends(get_db), admin: models.User = Depends(require_admin)):
    user = db.get(models.User, uid)
    if not user:
        raise HTTPException(404, "User not found")
    if user.id == admin.id:
        raise HTTPException(400, "You cannot delete your own account")
    db.delete(user); db.commit()
    write_log(db, admin, "Deleted user", user.username)
