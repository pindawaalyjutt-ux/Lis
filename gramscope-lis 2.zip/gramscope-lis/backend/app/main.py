from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .config import settings
from .database import Base, engine
from .routers import auth, users, patients, catalog, reports, misc

app = FastAPI(title="GramScope LIS API", version="2.0.0",
              description="Laboratory Information System backend - Designed by Kaleem Kahloon")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def _startup():
    Base.metadata.create_all(bind=engine)
    if settings.SEED_ON_START:
        from .seed import run
        run()


@app.get("/health")
def health():
    return {"status": "ok", "service": "gramscope-lis"}


app.include_router(auth.router)
app.include_router(users.router)
app.include_router(patients.router)
app.include_router(catalog.router)
app.include_router(reports.router)
app.include_router(misc.router)
