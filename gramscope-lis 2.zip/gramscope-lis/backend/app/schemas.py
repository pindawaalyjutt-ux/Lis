from datetime import datetime
from typing import Any, Optional
from pydantic import BaseModel, ConfigDict


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


# ---------- Auth ----------
class LoginIn(BaseModel):
    username: str
    password: str
    otp: Optional[str] = None


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: "UserOut"


class RegisterIn(BaseModel):
    name: str
    username: str
    email: str = ""
    password: str
    role: str = "Technician"


# ---------- Users ----------
class UserBase(BaseModel):
    name: str
    email: str = ""
    role: str = "Technician"
    permissions: list[str] = []
    active: bool = True
    two_fa: bool = False


class UserCreate(UserBase):
    username: str
    password: str


class UserUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[str] = None
    role: Optional[str] = None
    permissions: Optional[list[str]] = None
    active: Optional[bool] = None
    two_fa: Optional[bool] = None
    password: Optional[str] = None


class UserOut(ORM):
    id: str
    username: str
    name: str
    email: str
    role: str
    permissions: list[str]
    active: bool
    two_fa: bool
    last_login: Optional[datetime] = None
    password_set_at: Optional[datetime] = None
    created_at: Optional[datetime] = None


# ---------- Patients ----------
class PatientBase(BaseModel):
    name: str
    age: int = 0
    sex: str = ""
    contact: str = ""
    address: str = ""
    ward: str = ""
    specimen: str = ""
    physician: str = ""
    extra: dict[str, Any] = {}


class PatientCreate(PatientBase):
    pass


class PatientUpdate(BaseModel):
    name: Optional[str] = None
    age: Optional[int] = None
    sex: Optional[str] = None
    contact: Optional[str] = None
    address: Optional[str] = None
    ward: Optional[str] = None
    specimen: Optional[str] = None
    physician: Optional[str] = None
    extra: Optional[dict[str, Any]] = None


class PatientOut(ORM):
    id: str
    mr_no: str
    lab_no: str
    name: str
    age: int
    sex: str
    contact: str
    address: str
    ward: str
    specimen: str
    physician: str
    extra: dict[str, Any]
    created_at: Optional[datetime] = None


# ---------- Catalog ----------
class TemplateIn(BaseModel):
    name: str
    unit: str = ""
    ref_range: str = ""


class TemplateOut(ORM):
    id: str
    name: str
    unit: str
    ref_range: str


class CategoryIn(BaseModel):
    name: str


class CategoryOut(ORM):
    id: str
    name: str
    tests: list[TemplateOut] = []


# ---------- Reports ----------
class ReportCreate(BaseModel):
    patient_id: str
    type: str = "gram"
    category: str = ""
    status: str = "Draft"
    impression: str = ""
    explanation: str = ""
    image: str = ""
    result: dict[str, Any] = {}
    confidence: dict[str, Any] = {}
    metrics: dict[str, Any] = {}
    annotations: list[Any] = []
    tests: list[Any] = []


class ReportUpdate(BaseModel):
    status: Optional[str] = None
    impression: Optional[str] = None
    result: Optional[dict[str, Any]] = None
    tests: Optional[list[Any]] = None
    sign: Optional[dict[str, Any]] = None


class NoteIn(BaseModel):
    text: str


class ReportOut(ORM):
    id: str
    patient_id: str
    lab_no: str
    type: str
    category: str
    status: str
    impression: str
    explanation: str
    image: str
    result: dict[str, Any]
    confidence: dict[str, Any]
    metrics: dict[str, Any]
    annotations: list[Any]
    tests: list[Any]
    notes: list[Any]
    versions: list[Any]
    sign: Optional[dict[str, Any]] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


# ---------- Appointments / QC ----------
class AppointmentIn(BaseModel):
    patient_name: str
    doctor: str = ""
    date: str = ""
    time: str = ""
    reason: str = ""
    status: str = "Booked"


class AppointmentOut(ORM):
    id: str
    patient_name: str
    doctor: str
    date: str
    time: str
    reason: str
    status: str
    created_at: Optional[datetime] = None


class QCIn(BaseModel):
    control: str = ""
    expected: str = ""
    observed: str = ""
    reagent_lot: str = ""
    result: str = ""


class QCOut(ORM):
    id: str
    control: str
    expected: str
    observed: str
    reagent_lot: str
    result: str
    by: str
    created_at: Optional[datetime] = None


class AuditOut(ORM):
    id: str
    user: str
    role: str
    action: str
    target: str
    at: Optional[datetime] = None


Token.model_rebuild()
