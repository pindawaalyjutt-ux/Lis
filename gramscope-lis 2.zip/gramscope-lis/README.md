# GramScope LIS — Laboratory Information System

A multi-user Laboratory Information System: **FastAPI + PostgreSQL** backend,
**Electron** desktop wrapper (click-to-open installer), and a React frontend
(the `GramStainAI.jsx` app) with professional PDF/Excel reports carrying
Riphah International University branding.

> Designed by Kaleem Kahloon.

```
gramscope-lis/
├── docker-compose.yml         # Postgres + API, one command to run
├── backend/                   # FastAPI app (auth, RBAC, CRUD, audit)
│   ├── Dockerfile
│   ├── requirements.txt
│   └── app/ (main, models, schemas, routers, seed, security…)
├── desktop/                   # Electron wrapper -> .exe / .dmg / AppImage
└── frontend-integration/      # api.js client + how to wire the UI to the API
```

## 1. Run the backend + database (one command)
Requires Docker.
```bash
cd gramscope-lis
docker compose up --build
```
- API:        http://localhost:8000
- Swagger UI: http://localhost:8000/docs
- Health:     http://localhost:8000/health

On first start it auto-creates tables and seeds the catalog + demo users.

**Demo logins:** `admin`/`admin123`, `patho`/`patho123`, `micro`/`micro123`, `tech`/`tech123`.

### Run backend without Docker
```bash
cd backend
python -m venv .venv && source .venv/bin/activate    # Windows: .venv\Scripts\activate
pip install -r requirements.txt
# point DATABASE_URL at your Postgres (see .env.example), then:
uvicorn app.main:app --reload
```

## 2. Wire the frontend to the API
See `frontend-integration/README.md`. Short version: build the React app with Vite,
import `api.js`, and replace the local `store` calls with `api.*` calls. The PDF/Excel
generators need no change.

## 3. Build the desktop app (installable icon)
```bash
# build the frontend first, then:
cp -r <your-frontend>/dist/* desktop/renderer/
cd desktop
npm install
npm run build:win      # or build:mac / build:linux / build:all
```
Output installers land in `desktop/dist-desktop/`. On Windows this produces an NSIS
installer that adds a desktop shortcut and Start-menu entry — double-click to open.

During development you can run the shell live against Vite:
```bash
GRAMSCOPE_API_BASE=http://localhost:8000 npm run dev
```

## Security notes (production)
- Change `SECRET_KEY` and the Postgres password before deploying.
- Passwords are hashed with bcrypt; tokens are JWT (`Authorization: Bearer …`).
- Roles: Admin / Pathologist / Microbiologist / Technician, enforced per-endpoint.
- Account lockout after 5 failed logins (15 min); full audit trail in `audit_logs`.
- Put the API behind TLS (reverse proxy) and restrict `CORS_ORIGINS`.
- Email/SMS/OTP delivery and cloud backup are integration points — connect an SMTP/SMS
  provider and an object store; the schema and endpoints are ready for them.

## Architecture
- **Clean separation:** models ↔ schemas ↔ routers; dependencies for auth/RBAC/logging.
- **CRUD + search** for patients/reports/users/catalog; dashboard aggregates KPIs.
- **Report model** stores both Gram (AI) results and generic test panels (`type` field),
  with status workflow (Draft → Reviewed → Released), version history, notes, e-signature.
