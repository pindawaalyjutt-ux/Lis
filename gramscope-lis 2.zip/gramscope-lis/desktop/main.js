// Electron main process — wraps the built React frontend as a desktop app.
const { app, BrowserWindow, Menu, shell } = require("electron");
const path = require("path");

const DEV_URL = process.env.GRAMSCOPE_DEV_URL; // e.g. http://localhost:5173 during development

function createWindow() {
  const win = new BrowserWindow({
    width: 1360,
    height: 880,
    minWidth: 980,
    minHeight: 640,
    title: "GramScope LIS",
    icon: path.join(__dirname, "build", "icon.png"),
    backgroundColor: "#0B0D1A",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  if (DEV_URL) {
    win.loadURL(DEV_URL);
    win.webContents.openDevTools({ mode: "detach" });
  } else {
    // Production: load the bundled frontend (copy your Vite `dist` into ./renderer)
    win.loadFile(path.join(__dirname, "renderer", "index.html"));
  }

  // Open external links in the system browser, not inside the app.
  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: "deny" };
  });
}

app.whenReady().then(() => {
  Menu.setApplicationMenu(null); // clean, kiosk-like chrome; remove to keep default menu
  createWindow();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
