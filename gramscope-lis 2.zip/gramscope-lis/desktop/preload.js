// Minimal, safe bridge. Exposes the configured API base URL to the renderer.
const { contextBridge } = require("electron");

contextBridge.exposeInMainWorld("gramscope", {
  apiBase: process.env.GRAMSCOPE_API_BASE || "http://localhost:8000",
  platform: process.platform,
  version: "2.0.0",
});
